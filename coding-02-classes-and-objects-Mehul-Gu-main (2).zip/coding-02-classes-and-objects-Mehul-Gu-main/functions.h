/*
 * 
 * 
 * 
 * 
 */

/* 
 * File:   functions.h
 * Author: Mehul Gupta
 */

#ifndef CAR_FUNCTIONS_H
#define CAR_FUNCTIONS_H

#include <iostream>
#include "student_racecar.h"

void turnAndDisplayCar(Car*);
void turnAndDisplayStudentRacecar(StudentRacecar*);

#endif //CAR_FUNCTIONS_H
