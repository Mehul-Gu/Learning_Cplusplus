This is a classes and objects refresher assignment.

This code will take a speed, weight and the force on the steering wheel
to find the tire turn angle for a car. This tire turn angle will be used
along with the speed and a constant time of 5s to find the cars direction.
There will be a superclass Car and a subclass Student_Racecar which will
differ on the Student_Racecar having a university attribute. The student
racecar will also have its tire turn angle overloaded (as we assume no
power steering for a student racecar). Finally, the main file will run
through a number of test cases and output various scenarios with attention
paid to correct exception handling
